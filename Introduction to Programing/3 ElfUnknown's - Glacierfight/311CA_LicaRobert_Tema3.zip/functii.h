// Copyright Robert Lica robertlica21@gmail.com
#ifndef FUNCTII_H
#define FUNCTII_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include "./spiridusi.h"
void alloc_and_read(int ****matrix, FILE *in, int r);

#endif
