#!/bin/bash

# Copyright 2018 Darius Neatu (neatudarius@gmail.com)

total=0
MAX_POINTS=100.0

tests=21
declare -a points=(4.5 4.5 4.5 4.5 4.5 4.5 4.5 4.5 4.5 4.5 4.5 4.5 4.5 5.0 4.5 4.5 4.5 4.5 4.5 4.5 4.5)

TIMEOUT=10s
EXE=gigel

TESTS_DIR=tests
CLEAN=YES

function display_score() {
    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    
    status=0
    if [ ! -z "$1" ]; then
        status=$1
    fi

    if (( status != 0 )); then   
      exit $status
    fi

    echo "=================>>>>>> Total: $total/$MAX_POINTS  <<<<<<==================="

    if (( $(echo "$total==100.0" | bc -l ) )); then
        echo "======================>>>>>>  Ce boss!  <<<<<<======================="
    else
        CLEAN=NO
        echo "Compara rezultatele din tests/ref/*.ref cu tests/out/*.out să vezi care e buba."
    fi


    # clean junk and pwp
    if [[ $CLEAN = "YES" ]]; then
        rm -f tests/out/*.out
    fi

    exit $status
}

function check_readme() {
    README=README

    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    echo "========================>>>>>>    $README   <<<<<< ==================="

    score=0
    max_score=5

    if (( $(echo "$total == 0" |bc -l)  )); then
        echo "Punctaj $README neacordat. Punctajul pe teste este $total!"
    elif [ ! -f $README ]; then
        echo "$README lipsa."
    elif [ -f $README ] && [ "`ls -l $README | awk '{print $5}'`" == "0" ]; then
        echo "$README gol. (nice try)"
    else
        score=5
        total=$(bc <<< "$total + 5")
        echo "$README detectat. Punctajul final se va acorda la corectare."
    fi

    echo "========================>>>>>> score: $score/$max_score  <<<<<< ==================="
    printf "\n\n"
}

function check_cs_errors() {
    python cs.py *.h *.c 2> tmp
    cnt_cs=`cat tmp | grep "Total errors found" | cut -d ':' -f2 | cut -d ' ' -f2`
}

function check_coding_style() {
    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    echo "---------------------------------------------------------------------"
    echo "=====================>>>>>> Coding style <<<<<< ====================="

    cnt_cs=0
    check_cs_errors

    if (( cnt_cs > 0)); then
        total=$(bc <<< "$total -15")

        echo ""
        echo "$cnt_cs erori de CS. (-15p)"
        echo ""
        
        cat tmp | tail -20

    else
        echo "Nu au fost detectate erori de coding style in mod automat. Respect!"
        echo "Pot apărea însă depunctări la corectarea manuală (vezi enunț)."
    fi
    rm -f tmp

    printf "\n\n"
}

function test_howework() {
    test_index=-1
    for i in $(seq -f "%02g" 0 $(($tests-1)) ); do
      test_index=$((test_index + 1))
      test_points=${points[$test_index]}
      
      IN="tests/in/$i-gigel.in"
      OUT="tests/out/$i-gigel.out"
      REF="tests/ref/$i-gigel.ref"


      timeout $TIMEOUT ./$EXE < $IN > $OUT
      if [[ ! $? -eq 0 ]]; then
        echo "Test $i: BUBA -    0 /  $test_points"
      else
          diff $REF $OUT &> /dev/null
          if [ 0 -eq $? ]; then
            total=$(bc <<< "$total + $test_points")

            echo "Test $i: OK   -  $test_points /  $test_points"
          else
            echo "Test $i: WA   -    0 /  $test_points"
          fi
      fi
    done
}

gcc --version &> tmp; cat tmp | head -1
python --version
printf "\n"
    
# check if Makefile exists
if [ ! -f Makefile ]; then
    echo "Makefile lipsa. STOP"
    display_score 1
fi

# compile and check errors
make -f Makefile build &> out.make
if [ ! 0 -eq $? ]; then
    echo "Erori de compilare. STOP"

    cat out.make
    rm -f out.make
    
    display_score 1
fi

cnt=$(cat out.make | grep warning | wc -l)
if [ $cnt -gt 0 ]; then
    total=$(bc <<< "$total - 5")
    echo "Ai warning-uri la compilare. Rusine! (-5p)"

    cat out.make
    rm -f out.make

    echo ""
else
    # just for info
    cat out.make
    rm -f out.make
fi

mkdir -p tests/out &> /dev/null

# display tests set
echo "------------------------------ Run tests ----------------------------"
echo "Legenda:"
echo "         BUBA - programul NU se termina cu succes (SEGFAULT, TIMEOUT etc)"
echo "         WA   - Wrong Answer - programul se termina cu succes, insa nu produce rezultatul dorit"
echo "         OK   - programul se termina cu succes SI produce rezultatul dorit"
echo ""
echo ""

# run tests
test_howework

# clean junk
make -f Makefile clean &> /dev/null

check_coding_style
check_readme

# display result
display_score 0
