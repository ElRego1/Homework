#!/bin/bash

total_task1=15
total_task2=80
total_style=15
total_readme=5
MAX_POINTS=100
EXE1=hist
EXE2=stats
num_tests1=15
num_tests2=10
score_task1=0
score_task2=0
SCORE=0

rm -rf output
mkdir output 2> /dev/null
mkdir -p output/problema1 2> /dev/null
mkdir -p output/problema2 2> /dev/null

# Check if Makefile exists
if [ ! -f Makefile ]; then
  echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
  echo "|                                                     |"
  echo "| Dalek 1: Align and Advance!                         |"
  echo "| Dalek 2: Advance and Attack!                        |"
  echo "| Dalek 3: Attack and Destroy!                        |"
  echo "| All Daleks: Destroy and Rejoice!                    |"
  echo "| Dalek ship: Makefile not found. Process interrupted.|"
  echo "|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|"
  echo ""
  echo "==========> Total: $SCORE/$MAX_POINTS <=========="
  exit
fi

# Compile and check errors
make clean &> /dev/null
make build &> out.make
cnt=$(cat out.make| grep failed | wc -l)
rm -f out.make
if [ $cnt -gt 0 ]; then
  echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
  echo "|                                                                             |"
  echo "| Dalek Emperor: Danger! This is your Emperor speaking. There is danger here. |"
  echo "| The source code is not compiling succesfully. Retreat. Retreat.             |"
  echo "|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|"
  echo ""
  echo "==========> Total: $SCORE/$MAX_POINTS <=========="
  exit
fi

echo -e "==========> Check Task 1 - Histogram <=========="

for i in $(seq 1 $num_tests1); do
  IN_FILE="input/problema1/input${i}.in"
  OUT_FILE="output/problema1/output${i}.out"
  REF_FILE="ref/problema1/ref${i}.out"

  timeout 10s ./$EXE1 < $IN_FILE > $OUT_FILE

  t=$( diff -q $OUT_FILE $REF_FILE | wc -l )
  SCORE_TEST=$(( (total_task1 / num_tests1)*(1 - t) ))
  score_task1=$((score_task1 + SCORE_TEST))

  if [ $t -eq 0 ]; then
    echo "Test $i: ok ... $SCORE_TEST/$((total_task1 / num_tests1))"
  else
    echo "Test $i: failed ... $SCORE_TEST/$((total_task1 / num_tests1))"
  fi
done

echo -e "\nTask 1 score: $score_task1/$total_task1"

SCORE=$score_task1

echo -e "\n==========> Check Task 2 - Statistics <=========="

for i in $(seq 1 $num_tests2); do
  IN_FILE="input/problema2/input${i}.in"
  OUT_FILE="output/problema2/output${i}.out"
  REF_FILE="ref/problema2/ref${i}.out"

  timeout 10s ./$EXE2 < $IN_FILE > $OUT_FILE

  cat $OUT_FILE | head -8 > out_corectat

  t=$( diff out_corectat $REF_FILE | grep ">" | wc -l)
  SCORE_TEST=$(((total_task2/num_tests2)*(8 - t)/8))
  score_task2=$(( score_task2 + SCORE_TEST ))

  if [ $t -eq 0 ]; then
    echo "Test $i: ok ... $SCORE_TEST/$((total_task2/num_tests2))"
  else
    echo "Test $i: failed ... $SCORE_TEST/$((total_task2/num_tests2))"
  fi
  rm -f out_corectat
done

echo -e "\nTask 2 score: $score_task2/$total_task2"

SCORE=$((SCORE + score_task2))

check_coding_style_full() {
	echo -e "\n==========> Check Coding Style <=========="

	if [ $SCORE -eq 0 ]; then
		echo "Punctaj Coding style neacordat. Punctajul pe teste este $SCORE"
	else
    sources=$(find . -name '*.c' -o -name '*.h')
    chmod u+x cs.py
		./cs.py $sources &> c.errors
    cnt=$(cat c.errors | grep "Total errors found" | cut -d ':' -f2 | cut -d ' ' -f2)

		if [ $cnt -gt 0 ]; then
  		cat c.errors | tail -50
      SCORE=$((SCORE - total_style))

  		echo -e "$cnt C errors found.\n"
      echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
      echo "|                                               |"
      echo "| The coding style standards are not fully met. |"
      echo "| You will lose points based on this.           |"
      echo "| Dalek Prime Minister: Does it surprise you to |"
      echo "| know the Daleks have a concept of beauty?     |"
      echo "|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|"
		else
			echo -e "Coding style OK. Punctajul final se poate modifica la corectare."
		fi
	fi

	rm -f c.errors
}

check_coding_style_full

echo -e "\n==========> Check README <=========="
if [ ! -f README ]; then
  echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
  echo "|                                                       |"
  echo "| The Doctor: Identify me! Access your files. Who am I? |"
  echo "| Dalek: Error of accessing files. README not found.    |"
  echo "|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|"
  echo ""
else
  if [ $(cat README | wc -l) -eq 0 ]; then
    echo " _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ "
    echo "|                                                                 |"
    echo "| The Doctor: I'm part of you. My mind is in your mind.           |"
    echo "| Rusty, the Dalek: I see your mind, Doctor. I see your universe. |"
    echo "|     No, wait... the README is empty. I cannot see anything.     |"
    echo "|_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _|"
  else
    SCORE=$((SCORE + total_readme))
    echo "README score $total_readme"
  fi
fi

echo -e "\nFinal score: $SCORE/100"

make clean &> /dev/null
