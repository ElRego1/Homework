% TODO: compute a0, a1
function [a0, a1] = compute_gradient_descent_step_params(x, y, a0, a1, learning_rate)
	a0 = inf;
	a1 = inf;
endfunction
