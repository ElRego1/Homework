x = [1:10];                                          
y = [1.3, 3.5, 4.2, 5, 7, 8.8, 10.1, 12.5, 13, 15.6];

figure
plot(x, y, 'o');

title("Aproximare liniara in sensul celor mai mici patrate");
legend("f(x)");
