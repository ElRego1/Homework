% TODO: compute a0, a1
function [a0, a1] = compute_least_squares_linear_params(x, y)
	a0 = inf;
	a1 = inf;
endfunction
